Minetest 0.4 mod: car
=======================
by azekill_DIABLO. 

License of source code:
-----------------------
WTFPL

License of media (textures and sounds):
---------------------------------------
WTFPL

Authors of media files:
-----------------------
textures: azekill_DIABLO